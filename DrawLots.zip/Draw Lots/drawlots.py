import tkinter as tk
import random


def create_entry_fields():
    for widget in frame.winfo_children():
        widget.destroy()
    
    try:
        count = int(entry_count.get())
        global entries
        entries = []
        
        for i in range(count):
            entry = tk.Entry(frame, font=("Arial", 14), width=30)
            entry.pack(pady=5)
            entries.append(entry)
    except ValueError:
        result_label.config(text="Please enter a valid number.")


def draw_winners():
    try:
        winner_count = int(entry_winner_count.get())
        choices = [entry.get() for entry in entries if entry.get()]
        
        if winner_count > len(choices):
            result_label.config(text="Not enough entries for winners.")
            return
        
        winners = random.sample(choices, winner_count)
        result_label.config(text=f"Winners: {', '.join(winners)}")
    except ValueError:
        result_label.config(text="Please enter a valid number.")


def reset_application():
    for widget in frame.winfo_children():
        widget.destroy()
    
    entry_count.delete(0, tk.END)
    entry_winner_count.delete(0, tk.END)
    
    result_label.config(text="")


root = tk.Tk()
root.title("Draw Lots")
root.geometry("400x400") 
root.configure(bg="#f0f0f0")  

# Yeni etiket ekleme
producer_label = tk.Label(root, text="Made By: Butcher3-8", font=("Arial", 12), bg="#f0f0f0")
producer_label.pack(anchor="nw", padx=10, pady=10)  

title_label = tk.Label(root, text="DRAW LOTS", font=("Arial", 24, "bold"), bg="#f0f0f0")
title_label.pack(pady=10)

frame = tk.Frame(root, bg="#f0f0f0")
frame.pack(pady=10)

label_count = tk.Label(root, text="Number of entries:", font=("Arial", 12), bg="#f0f0f0")
label_count.pack(pady=5)
entry_count = tk.Entry(root, font=("Arial", 14), width=30)
entry_count.pack(pady=5)

button_create = tk.Button(root, text="Create Entry Fields", command=create_entry_fields, font=("Arial", 12), bg="#4CAF50", fg="white")
button_create.pack(pady=5)

label_winner_count = tk.Label(root, text="Number of winners:", font=("Arial", 12), bg="#f0f0f0")
label_winner_count.pack(pady=5)
entry_winner_count = tk.Entry(root, font=("Arial", 14), width=30)
entry_winner_count.pack(pady=5)

button_draw = tk.Button(root, text="Go", command=draw_winners, font=("Arial", 12), bg="#2196F3", fg="white")
button_draw.pack(pady=5)

button_reset = tk.Button(root, text="Reset", command=reset_application, font=("Arial", 12), bg="#f44336", fg="white")
button_reset.pack(pady=5)

result_label = tk.Label(root, text="", font=("Arial", 12), bg="#f0f0f0")
result_label.pack(pady=10)

root.mainloop()
